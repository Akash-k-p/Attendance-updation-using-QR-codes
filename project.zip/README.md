# qr-reader-attendance-system

QR reader + attendance system with Python and OpenCV !

[![Watch the video](https://img.youtube.com/vi/5eahBYvDJjA/0.jpg)](https://www.youtube.com/watch?v=5eahBYvDJjA)
