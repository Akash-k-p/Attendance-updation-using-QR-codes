        print(data)
        print(rect)
        print(polygon)